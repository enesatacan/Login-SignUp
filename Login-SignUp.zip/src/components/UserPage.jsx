import React, { useContext } from "react";
import { MyContext } from "../Context/MyContext";
import Button from "../UI/Button";
import Card from "../UI/Card";
function UserPage() {
  const { userName, handleLogout, loggedInUser } = useContext(MyContext);

  return (
    <Card>
      <div className="inline-block mt-20">
        <p className="text-3xl text-indigo-700">{userName}</p>
        <p className="m-5">Welcome, {userName} </p>
        {loggedInUser && <p>Email: {loggedInUser.email}</p>}
        <Button onClick={handleLogout} className="border-indigo-700 mt-10">
          Log Out
        </Button>
      </div>
    </Card>
  );
}

export default UserPage;
