import React, { useContext } from "react";
import Button from "../UI/Button";
import { MyContext } from "../Context/MyContext";
function SignUp() {
  const { handleRelocation } = useContext(MyContext);
  return (
    <>
      <span className="text-3xl font-bold">Hi, User</span>
      <span className="text-lg m-2">
        Don't have an account yet? <br /> Let's create an account for you right
        now.
      </span>
      <Button onClick={handleRelocation}>Sign Up</Button>
    </>
  );
}

export default SignUp;
