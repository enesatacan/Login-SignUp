import React from "react";
import Card from "../UI/Card";
import SignUpContainer from "./SignUpContainer";
import LoginContainer from "./LoginContainer";
function MainPage() {
  return (
    <Card className="card  grid grid-cols-1 md:grid-cols-2 p-0">
      <LoginContainer className="col-span-1 md:col-span-2" />
      <SignUpContainer className="col-span-1 md:col-span-2" />
    </Card>
  );
}

export default MainPage;
