import React, { useContext } from "react";
import Button from "../UI/Button";
import { MyContext } from "../Context/MyContext";

function Login() {
  const { handleRelocation } = useContext(MyContext);
  return (
    <>
      <span className="text-3xl font-bold">Hi, User</span>
      <span className="text-lg m-2">
        Already have an account? <br /> Now let's log in to your account
      </span>
      <Button onClick={handleRelocation}>Login</Button>
    </>
  );
}

export default Login;
