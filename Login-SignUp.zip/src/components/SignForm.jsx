import Input from "../UI/Input";
import Button from "../UI/Button";
import { useContext } from "react";
import { MyContext } from "../Context/MyContext";
function SignForm() {
  const {
    handleSubmit,
    setCreateUsername,
    setCreateEmail,
    setCreatePassword,
    setCreatePasswordAgain,
    createUsername,
    createEmail,
    createPassword,
    createPasswordAgain,
    createNewUser,
    existingUserControl,
    passwordMatch,
  } = useContext(MyContext);

  return (
    <>
      {createNewUser ? (
        <div>
          <p>Your Account is Created </p>
          <p>You are Redirected to the Login Page </p>
        </div>
      ) : (
        <div className="flex flex-col gap-3 mt-5 p-10">
          <span className="text-3xl font-bold  text-indigo-700">
            Create <br /> Account
          </span>
          <form className="flex flex-col gap-3" onSubmit={handleSubmit}>
            <Input
              onChange={(e) => {
                setCreateUsername(e.target.value);
              }}
              value={createUsername}
              placeholder="Username"
              type="text"
            />
            <Input
              onChange={(e) => {
                setCreateEmail(e.target.value);
              }}
              value={createEmail}
              placeholder="Email"
              type="email"
            />
            <Input
              onChange={(e) => {
                setCreatePassword(e.target.value);
              }}
              value={createPassword}
              placeholder="Password"
              type="password"
            />
            <Input
              onChange={(e) => {
                setCreatePasswordAgain(e.target.value);
              }}
              value={createPasswordAgain}
              placeholder="Password Again"
              type="password"
            />
            {existingUserControl && (
              <p className="bg-indigo-800 text-white p-2 rounded-lg">
                Username or Email already exists!
              </p>
            )}
            {passwordMatch && (
              <p className="bg-indigo-800 text-white p-2 rounded-lg">
                Passwords do not match!
              </p>
            )}

            <Button className="border-indigo-700 mt-5">Sign Up</Button>
          </form>
        </div>
      )}
    </>
  );
}

export default SignForm;
