import React, { useContext } from "react";
import SignUp from "./SignUp";
import SignForm from "./SignForm";
import { MyContext } from "../Context/MyContext";

function SignUpContainer() {
  const { relocation } = useContext(MyContext);
  return (
    <div
      className={`flex flex-col items-center justify-center ${
        relocation
          ? "bg-gradient-to-r from-indigo-800 to-indigo-400  text-white rounded-e-2xl transition  ease-in duration-300"
          : ""
      }
        `}
    >
      {relocation ? <SignUp /> : <SignForm />}
    </div>
  );
}

export default SignUpContainer;
