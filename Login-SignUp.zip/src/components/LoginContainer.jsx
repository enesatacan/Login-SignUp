import React, { useContext } from "react";
import LoginForm from "./LoginForm";
import Login from "./Login";
import { MyContext } from "../Context/MyContext";

function LoginContainer() {
  const { relocation } = useContext(MyContext);
  return (
    <div
      className={`flex flex-col items-center justify-center ${
        relocation
          ? ""
          : "bg-gradient-to-r from-indigo-800 to-indigo-400  text-white rounded-s-2xl transition ease-in-out duration-300"
      }
        `}
    >
      {relocation ? <LoginForm /> : <Login />}
    </div>
  );
}

export default LoginContainer;
