import { useContext } from "react";
import Input from "../UI/Input";
import Button from "../UI/Button";
import { MyContext } from "../Context/MyContext";
function LoginForm() {
  const {
    handleLogin,
    userName,
    setUserName,
    setPassword,
    password,
    lengthError,
    loginError,
  } = useContext(MyContext);
  return (
    <>
      <div className="flex flex-col gap-3 mt-5 p-10">
        <span className="text-3xl font-bold text-indigo-700">Login</span>
        <Input
          value={userName}
          onChange={(e) => {
            setUserName(e.target.value);
          }}
          placeholder="Username"
          type="text"
        />
        <Input
          value={password}
          onChange={(e) => {
            setPassword(e.target.value);
          }}
          placeholder="Password"
          type="password"
        />
        {loginError && (
          <p className="bg-indigo-800 text-white p-2 rounded-lg">
            Your Login is Incorrect!
          </p>
        )}
        {lengthError && (
          <p className="bg-indigo-800 text-white p-2 rounded-lg">
            Your Login Information Must Be Complete!
          </p>
        )}

        <Button onClick={handleLogin} className="border-indigo-700">
          Login
        </Button>
      </div>
    </>
  );
}

export default LoginForm;
