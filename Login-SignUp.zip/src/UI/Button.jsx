function Button(props) {
  return (
    <button
      onClick={props.onClick}
      className={`rounded-md border-2 p-2 w-20 ml-auto mr-auto mb-5 ${props.className}`}
    >
      {props.children}
    </button>
  );
}

export default Button;
