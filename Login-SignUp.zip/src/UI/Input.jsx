function Input(props) {
  return (
    <input
      type={props.type}
      value={props.value}
      onChange={props.onChange}
      placeholder={props.placeholder}
      className={`rounded-md px-6 p-2 m-auto border-2 focus:border-indigo-700 focus:outline-none transition ease-in duration-300 ${props.className}`}
    />
  );
}

export default Input;
