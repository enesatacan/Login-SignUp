import { useContext } from "react";
import "./App.css";
import MainPage from "./components/MainPage";
import { Route, Routes } from "react-router-dom";
import { MyContext } from "./Context/MyContext";
import UserPage from "./components/UserPage";

function App() {
  const { userName } = useContext(MyContext);
  return (
    <>
      <Routes>
        <Route path="/" element={<MainPage />} />
        {userName && <Route path={`/${userName}`} element={<UserPage />} />}
      </Routes>
    </>
  );
}

export default App;
