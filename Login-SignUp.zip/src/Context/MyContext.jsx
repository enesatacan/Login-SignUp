import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export const MyContext = React.createContext();

export const MyProvider = ({ children }) => {
  const [relocation, setRelocation] = useState(true);
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [lengthError, setLengthError] = useState(false);
  const [loginError, setLoginError] = useState(false);
  const [loggedInUser, setLoggedInUser] = useState(null);
  const [createUsername, setCreateUsername] = useState("");
  const [createEmail, setCreateEmail] = useState("");
  const [createPassword, setCreatePassword] = useState("");
  const [passwordMatch, setPasswordMatch] = useState(false);
  const [existingUserControl, setExistingUserControl] = useState(false);
  const [createPasswordAgain, setCreatePasswordAgain] = useState("");
  const [createNewUser, setCreateNewUser] = useState(false);
  const [users, setUsers] = useState([]);

  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsers = async () => {
      const response = await fetch("http://localhost:3000/api/users");
      const data = await response.json();
      setUsers(data);
    };

    fetchUsers();
  }, []);
  useEffect(() => {
    if (lengthError || loginError || existingUserControl || passwordMatch) {
      const timer = setTimeout(() => {
        setLengthError(false);
        setLoginError(false);
        setExistingUserControl(false);
        setPasswordMatch(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [lengthError, loginError, existingUserControl, passwordMatch]);

  const handleRelocation = () => {
    setRelocation((prevState) => !prevState);
  };

  const handleLogin = () => {
    if (userName.trim().length === 0 || password.trim().length === 0) {
      setLengthError(true);
      console.log("Your Login Information Must Be Complete!");
      return;
    }

    const user = users.find(
      (user) => user.username === userName && user.password === password
    );

    if (user) {
      console.log("Your Login is Correct!");
      setLoggedInUser(user);
      navigate(`/${userName}`);
    } else {
      setLoginError(true);
      console.log("Your Login is Incorrect!");
    }

    setPassword("");
  };

  const handleLogout = () => {
    setLoggedInUser(null);
    setUserName("");
    navigate("/");
  };

  const addUserToData = async (newUser) => {
    const response = await fetch("http://localhost:3000/api/users", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ users: [newUser] }),
    });

    if (response.ok) {
      console.log("New user added successfully", newUser);
      setUsers((prevUsers) => [...prevUsers, newUser]);
    } else {
      console.error("An error occurred while adding a user");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (createPassword !== createPasswordAgain) {
      console.log("Passwords do not match!");
      setPasswordMatch(true);
      return;
    }

    const existingUser = users.find(
      (user) => user.username === createUsername || user.email === createEmail
    );

    if (existingUser) {
      console.log("Username or Email already exists!");
      setExistingUserControl(true);
      return;
    }

    const newUser = {
      username: createUsername,
      email: createEmail,
      password: createPassword,
    };

    addUserToData(newUser);

    setCreateUsername("");
    setCreateEmail("");
    setCreatePassword("");
    setCreatePasswordAgain("");
    setCreateNewUser(true);

    setTimeout(() => {
      window.location.reload();
    }, 2500);
  };

  const value = {
    relocation,
    setRelocation,
    handleRelocation,
    setPassword,
    password,
    setUserName,
    userName,
    loggedInUser,
    handleLogin,
    lengthError,
    loginError,
    existingUserControl,
    passwordMatch,
    handleLogout,
    handleSubmit,
    setCreateUsername,
    setCreateEmail,
    setCreatePassword,
    setCreatePasswordAgain,
    createUsername,
    createEmail,
    createPassword,
    createPasswordAgain,
    createNewUser,
  };

  return <MyContext.Provider value={value}>{children}</MyContext.Provider>;
};
