const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(bodyParser.json());

let users = [];

// Kullanıcıları eklemek için bir endpoint
app.post("/api/users", (req, res) => {
  const newUsers = req.body.users;

  if (Array.isArray(newUsers)) {
    users = [...users, ...newUsers]; // Yeni kullanıcıları ekleyin
    res.status(201).send({ message: "Users added successfully!", users });
  } else {
    res.status(400).send({ message: "Invalid data format." });
  }
});

// Kullanıcıları almak için bir endpoint
app.get("/api/users", (req, res) => {
  res.send(users);
});

// Sunucuyu başlat
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
